-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-03-2022 a las 23:44:55
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `alquiler`
--
CREATE DATABASE IF NOT EXISTS `alquiler` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `alquiler`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alquiler`
--

CREATE TABLE `alquiler` (
  `id_alquiler` int(11) NOT NULL,
  `id_vehiculo` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha_alquiler` int(11) DEFAULT NULL,
  `fecha_devolucion` int(11) DEFAULT NULL,
  `Costo_alquiler` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Logo` blob DEFAULT NULL,
  `Descripcion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `Dui` int(11) NOT NULL,
  `Nit` int(11) DEFAULT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Direccion` varchar(50) DEFAULT NULL,
  `Contacto_cli` int(11) DEFAULT NULL,
  `Referencia_personal` varchar(60) DEFAULT NULL,
  `Contacto_ref` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `id_emple` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `turno` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especarro`
--

CREATE TABLE `especarro` (
  `id_espec` int(11) NOT NULL,
  `color` varchar(30) DEFAULT NULL,
  `Modelo` varchar(30) DEFAULT NULL,
  `año` int(11) DEFAULT NULL,
  `capacidad` int(11) DEFAULT NULL,
  `N_placa` varchar(15) DEFAULT NULL,
  `N_Chasis` varchar(30) DEFAULT NULL,
  `N_motor` varchar(30) DEFAULT NULL,
  `Fotografia` blob DEFAULT NULL,
  `Comentarios` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `especarro`
--

INSERT INTO `especarro` (`id_espec`, `color`, `Modelo`, `año`, `capacidad`, `N_placa`, `N_Chasis`, `N_motor`, `Fotografia`, `Comentarios`) VALUES
(1, 'Rojo', 'Toyota', 2011, 5, 'AB59-9', '4567fdf648746', '454848dadf4', NULL, 'Ninguno'),
(2, 'negro', 'Nissan', 2015, 5, '459-9', '4564df8a4d', '54fd84fd5', NULL, 'pequeño golpe trasero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `espefalquiler`
--

CREATE TABLE `espefalquiler` (
  `Id_espe` int(11) NOT NULL,
  `Id_alquiler` int(11) DEFAULT NULL,
  `Cant_carro` int(11) NOT NULL,
  `Cant_pagar` int(11) NOT NULL,
  `Nombre_cliente` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id_probe` int(11) NOT NULL,
  `marca` varchar(30) DEFAULT NULL,
  `cant_carros` int(11) DEFAULT NULL,
  `precio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id_probe`, `marca`, `cant_carros`, `precio`) VALUES
(1, 'Toyota', 10, 6000),
(2, 'nissan', 6, 5900);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usurio`
--

CREATE TABLE `usurio` (
  `Usuario` varchar(20) DEFAULT NULL,
  `Contraseña` varchar(15) NOT NULL,
  `T_user` varchar(14) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Apellido` varchar(20) NOT NULL,
  `Correo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usurio`
--

INSERT INTO `usurio` (`Usuario`, `Contraseña`, `T_user`, `Nombre`, `Apellido`, `Correo`) VALUES
('AleMejia01', 'Al3j4ndr0', 'Administrador', 'Alejandro', 'Mejia', 'alemejia0@hotmail.com'),
('jkmejia', 'J4ckMejia', 'Usuario', 'Jackeline', 'Mejia', 'jmejia04@hotmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `id_vehiculo` int(11) NOT NULL,
  `id_espec` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `N_placa` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alquiler`
--
ALTER TABLE `alquiler`
  ADD PRIMARY KEY (`id_alquiler`);

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`Dui`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`id_emple`);

--
-- Indices de la tabla `especarro`
--
ALTER TABLE `especarro`
  ADD PRIMARY KEY (`id_espec`);

--
-- Indices de la tabla `espefalquiler`
--
ALTER TABLE `espefalquiler`
  ADD PRIMARY KEY (`Id_espe`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id_probe`);

--
-- Indices de la tabla `usurio`
--
ALTER TABLE `usurio`
  ADD PRIMARY KEY (`Contraseña`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`id_vehiculo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alquiler`
--
ALTER TABLE `alquiler`
  MODIFY `id_alquiler` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empleado`
--
ALTER TABLE `empleado`
  MODIFY `id_emple` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `especarro`
--
ALTER TABLE `especarro`
  MODIFY `id_espec` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id_probe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  MODIFY `id_vehiculo` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
